//4.1.
class person {
    constructor(fname, lname, age, city) {
        this.fname = fname;
        this.lname = lname;
        this.age = age;
        this.city = city;
    }
    info() {
        console.log('Име: ' + this.fname);
        console.log('Фамилия: ' + this.lname);
        console.log('Възраст: ' + this.age);
        console.log('Град: ' + this.city);
    }
    isBurgas(){
        if(this.city == 'Бургас'){
            console.log(`${this.fname} е от ${this.city}`);
        }
        else{
            console.log(this.fname + ' не е от Бургас');
        }
    }
}

let taras = new person('Тарас', 'Фамилен', 25, 'Бургас');
taras.info();
taras.isBurgas();
console.log(' ');

let ivan = new person('Иван', 'Фамилен', 25, 'София');
ivan.info();
ivan.isBurgas();
console.log(' ');
//

//4.2.

class Movie {
    constructor(name, year, country, rating, artists){
        this.name = name;
        this.year = year;
        this.country = country;
        this.rating = rating;
        this.artists = artists;
    }
}

Movie.prototype.info = function() {
    console.log('Име: ' + this.name);
    console.log('Година на създаване: ' + this.year);
    console.log('Държава: ' + this.country);
    console.log('Рейтинг: ' + this.rating);
}

Movie.prototype.changerating = function(newrating) {
    this.newrating = newrating;
    this.rating = this.newrating;
    console.log('Нов рейтинг на ' + this.name + ': ' + this.newrating);  
}

Movie.prototype.splice = function() {
    delete this.name;
    delete this.rating;
}

Movie.prototype.addArtists = function(newartists){
    this.newartists = newartists;
    this.artists += this.newartists;
    //this.artists.push(newartists);
    console.log("Артисти: " + this.artists);
}

Movie.prototype.checkArtists = function(artist) {
    this.artist = artist;
    for(let i = 0; i < this.artists.length; i++){
        if(this.artist == this.artists[i]){
            console.log(this.artist + ' участва в филм')
        }
        else if(this.artist != this.artists[i]) {
            console.log(this.artist + ' не участва в филм')
        }
    }
}

let movie = new Movie('Филм', 2000, 'България', 5, ['Пешо', 'Гошо']);

movie.info();
console.log(' ');

movie.changerating(6);
movie.info();
console.log(' ');

movie.splice();
movie.info();
console.log(' ');

movie.addArtists('Иван')

movie.checkArtists('Пешо')