//2.2.
let arr = [3, 3, 4, 5, 6, 4];
let newarray = [];
let count = 0;
for(let i = 0; i < arr.length; i++){
    if(arr[i] == 3 || arr[i] == 4) {
        newarray.push(arr[i])
        count += 1;
    }
}

console.log(newarray);
console.log(count);
//

//2.4.
let namearr = ["иван", "гошо", "пешо", "имена"];
console.log(namearr);

let nameArr =  namearr;

for(let i = 0; i < nameArr.length; i++){
    if(nameArr[i].includes('а')){

        nameArr.splice(i, i);

    }
}

//let res = namearr.filter(letter => letter.includes('а'));
console.log(nameArr);
//

//2.5.
let newArr = [];
for (let i = 0; i < namearr.length; i++) {
    newArr[i] = namearr[i][0].toUpperCase() + namearr[i].substring(1);
}

console.log(newArr);
//

//2.6
let vowels = ["а","ъ", "о", "у", "е", "и"];
let num = 0;
for(let i = 0; i < namearr.length; i++){

    let splitnamearr = namearr[i].split("");

    for(let v = 0; v < vowels.length; v++){
        if(splitnamearr.includes(vowels[v])){
            num +=1;
            //console.log(vowels[v]);
        }
    }
}
console.log(num);