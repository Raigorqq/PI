//1.A.
let A1 = "аз уча javascript";

let newA1 = A1[0].toUpperCase() + A1.substring(1);

console.log(newA1);
//

//1.D.

let newD1 = A1.replace("уча", "обичам");

console.log(newD1);
//


//2.A.

let A2 = "софия пловдив варна бургас плевен";
let newA2 = A2.split(" ");

console.log(newA2);
//

//2.B.
let newB2 = A2.split(" ");

for (let i = 0; i < newB2.length; i++) {
    newB2[i] = newB2[i][0].toUpperCase() + newB2[i].substring(1);
}

newB2.join(" ");

console.log(newB2);
//

//2.C.
let newC2 = A2.split(" ");
let count = 0;
let letter = "а";
for (let i = 0; i < newC2.length; i++){
    for(const char of newC2[i]){
        if(letter.includes(char)){
            count +=1;
        }
    }
    
}
console.log('брой: ' + count)
//

//2.D.
let arr = [];
let i = 0;
for(const char of A2){
    
    arr[i] = char;
    
    i +=1;
}
console.log(arr)
//

//3.A.
let data = "2017-09-21";
let splitdata = data.split("-");

let newdata = splitdata[2] + "." + splitdata[1] + "." + splitdata[0];

console.log(newdata);
//
