function process(arr){
    console.log(arr);


}
//1.1.
function f1(callback){
    let a = [4, 5, 6]
    console.log(a)
    sum = 0
    for(let i =0; i < a.length; i++){
        sum += a[i];
    }

    callback(sum);
}

f1(process);
//

//1.2
function f2(callback){
    let a = [4, 5, 6]
    console.log(a)
    a.push(7);

    callback(a);
}
f2(process);
//

//2
function greetingTemp(greeting, name){
    console.log(greeting);
}

function greetingPers(name){
    return name
}

function morning(callback){
    let Morning = "Добро утро, ";
    callback(Morning);

}

function evening(callback){
    let Evening = "Добър вечер, ";
    callback(Evening);
}


console.log(morning(greetingTemp) + greetingPers('Иван!'));
//

//3
function makeList(groupname){

}

function addName(name, groupname){
    let newstudent = {groupname: groupname, name: name}
    list.push(newstudent)
}

let list = [{ groupname: 'KST100', name: 'Иван'},
            { groupname: 'KST101', name: 'Пешо'},
            { groupname: 'KST102', name: 'Гошо'}
];
console.log(list)

addName('KST103', 'Стефан');
console.log(list)